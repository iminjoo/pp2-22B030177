def to_ounces(gramm):
    return gramm*28.3495231
print(to_ounces(int(input())))