import math
def volume_sphere(radius):
    return (math.pi*radius**3)*4/3
print(volume_sphere(int(input())))