import random
from guess import guess_the_number
print('GAME OVER')