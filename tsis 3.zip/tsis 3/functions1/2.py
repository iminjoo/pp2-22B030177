def to_centigrate(F):
    return (5/9)*(F-32)
print(to_centigrate(int(input())))